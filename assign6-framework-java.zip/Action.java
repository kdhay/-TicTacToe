/**
 * An interface to be implemented by any action in the context of the MiniMax algorithm. 
 */
public interface Action {
	
}
